$(document).ready(function(){ slideShow();  });

function slideShow(){
		var trenutna = $('#slike .aktivna');
		var sledeca = trenutna.next().length ? trenutna.next() : trenutna.parent().children(':first');
		trenutna.removeClass('aktivna');
		sledeca.addClass('aktivna');
		setTimeout(slideShow, 7000);
		
	}
document.querySelector("#next").addEventListener("click", nextPhoto);	
function nextPhoto(){
	var trenutna = $('#slike .aktivna');
	var sledeca = trenutna.next().length ? trenutna.next() : trenutna.parent().children(':first');
	trenutna.removeClass('aktivna');
	sledeca.addClass('aktivna');
}

document.querySelector("#prev").addEventListener("click", prevPhoto);	
function prevPhoto(){
	var trenutna = $('#slike .aktivna');
	var prethodna = trenutna.prev() ? trenutna.prev() : trenutna.parent().children(':last');
	trenutna.removeClass('aktivna');
	prethodna.addClass('aktivna');
}

