;(function () {
	
	var dropDownMenu = function() {
	 	$(".drop-down-menu").hover(function(){
         $(this).addClass('active');
    	},
    	function(){
        	$(this).removeClass('active');
    	});

	};

	var loaderPage = function() {
		$(".loader").fadeOut("slow");
	};

	var goToTop = function() {

		$('.js-gotop').on('click', function(event){
			
			event.preventDefault();

			$('html, body').animate({
				scrollTop: 0
				}, 800);
				return false;
		});

		$(window).scroll(function(){

			var $win = $(window);
			if ($win.scrollTop() > 100) {
				$('.js-top').addClass('active');
			} else {
				$('.js-top').removeClass('active');
			}

		});
	
	};



	var offcanvasMenu = function() {
		$('#wrap').prepend('<div id="offcanvas" />');
		$('#offcanvas').append( $('#main-nav').clone() );
	};


	var ddMenu = function() {

		$('body').on('click', '.js-nav-toggle', function(event){
			var $this = $(this);

			if ( $('body').hasClass('offcanvas-visible') )  {
				$('body').removeClass('overflow offcanvas-visible');
				$this.removeClass('active');
			} else {
				$('body').addClass('overflow offcanvas-visible');
				$this.addClass('active');
			}

			event.preventDefault();

		});

		$('#offcanvas').css('height', $(window).height());

		$(window).resize(function() {
			$('#offcanvas').css('height', $(window).height());
			if ( $('body').hasClass('offcanvas-visible') ) {
		   	$('body').removeClass('offcanvas-visible');
		   	$('.js-nav-toggle').removeClass('active');
		   }
		});

		$(window).scroll(function(){
			if ( $('body').hasClass('offcanvas-visible') ) {
		   	$('body').removeClass('offcanvas-visible');
		   	$('.js-nav-toggle').removeClass('active');
		   }
		});

	};
	
	

	

	
	// Document on load.
	$(function(){
		dropDownMenu();
		offcanvasMenu();
		ddMenu();
		loaderPage();
		goToTop();
	});


}());