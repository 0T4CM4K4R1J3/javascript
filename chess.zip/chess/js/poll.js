$(document).ready(function() {
	
	$("#btnVote").click(function(){
		var vote = $("input[name='rbOpen']:checked").val();
		vote = parseInt(vote);
		
		
		var voteObj = { "vote": vote}
		$.ajax({
				type: 'POST',
				url: 'poll.php',
				// dataType: 'json', - vraca se tekst
				data: voteObj,
				success: function(podaci){
					console.log(podaci);
				},
				error : function(greske){
					console.log(greske);
				}
			});
	} );
	
	$("#btnGetVotes").click(function(){
		
		$.ajax({
				type: 'GET',
				url: 'poll.txt',
				success: function(podaci){
					podaci=podaci.split("||");
					var tekst = "</br>";
					
					
					tekst += "<table class='table'><tr><td>Ruy Lopez</td><td>"+podaci[0]+"</td></tr>";
					tekst += "<tr><td>Queen Gambit</td><td>"+podaci[1]+"</td></tr>";
					tekst += "<tr><td>King Gambit</td><td>"+podaci[2]+"</td></tr>";
					tekst += "<tr><td>Sicilian Defense</td><td>"+podaci[3]+"</td></tr></table>";
					
					$("#show").html(tekst);
				}
				
			});
			
			
	} );
	
	
} );