window.onload = function()
{
	//fokus na prvo input polje
	document.getElementById("name").focus();
	
	
	//Klikom na dugme poziva se funkcija provera()
	document.getElementById("taster").addEventListener("click", provera);
}

//ddlista
window.addEventListener("load", napraviListu);
function napraviListu()
{
	var izbor, ispis, broj;

	izbor	= new Array("Opening", "Midle game", "End Game");
	
	ispis = "<select id='ddlIzbor'>";
	ispis += "<option value='0'>Please select</option>";
	for(var i = 0; i < izbor.length; i++)
	{	
		broj = i + 1;
		ispis += "<option value='"+broj+"'>" + izbor[i] + "</option>";
	}
	ispis += "</select>";
	
	document.getElementById("lista").innerHTML = ispis;
}
//Funkcija koja proverava ispravnost unetih vrednosti u elemente formulara
function provera()
{	
	//definisanje potrebnih promenljivih
	var name, email, gender, genderIzbor, interest, interestIzbor, openings, openingsIzbor, regname, message, regMessage, regEmail, nizOk, nizGreske, rezultat;
	
	//Preuzimanje vrednosti iz formulara
	name = document.getElementById("name").value;
	email = document.getElementById("email").value;
	message = document.getElementById("message").value;
	//radio button
	gender = document.getElementsByName("rbGender");
	genderIzbor = "";
	for(var i = 0; i < gender.length; i++)
	{
		if(gender[i].checked)
		{
			genderIzbor += gender[i].value;
			break;
		}
	}
	//check box
	interest = document.getElementById("ddlIzbor");
	interestIzbor = interest.options[interest.selectedIndex].value;
	
	openings = document.getElementsByName("chbOpenings");
	openingsIzbor = "";
	for(var i = 0; i < openings.length; i++)
	{
		if(openings[i].checked)
		{
			openingsIzbor += openings[i].value + " ";
		}
	}
	//definisanje regularnih izraza
	regname = /^[A-Z][a-z]{2,9}(\s[A-Z][a-z]{2,9})+$/;
	regEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
	regMessage = /^([A-z\s0-9\@\!\.\?]{2,100})+$/;
	
	//niz za greske i pravilno napisane podatke
	nizGreske = new Array();
	nizOk = new Array();
	
	//provera vrednosti iz formulara
	if(!regname.test(name))
	{
		nizGreske.push("Please insert only letters in field name. FirstName LastName");
	}
	else
	{
		nizOk.push("Name: " + name);
	}
	
	if(!regEmail.test(email))
	{
		nizGreske.push("Please input valid email!");
	}
	else
	{
		nizOk.push("Email: " + email);
	}
	
	if(genderIzbor == "")
	{
		nizGreske.push("Gender not selected!");
	}
	else
	{
		nizOk.push("Gender: " + genderIzbor);
	}
	
	if(interestIzbor == "0")
	{
		nizGreske.push("Choose interest!");
	}
	else
	{
		nizOk.push("interest: " + interest.options[interest.selectedIndex].text);
	}
	
	if(openingsIzbor == "")
	{
		nizGreske.push("Choose at least 1 opening");
	}
	else
	{
		nizOk.push("Openings: </br>" + openingsIzbor);
	}
	
	if(!regMessage.test(message))
	{
		nizGreske.push("Please leave a message. Only letters and numbers allowed");
	}
	else
	{
		nizOk.push("Message: " + message);
	}
	
	
	//Ispisivanje gresaka ili pravilno napisanih podataka
	rezultat = "<ul>";
	if(nizGreske.length != 0)
	{
		for(var i = 0; i < nizGreske.length; i++)
		{
			rezultat += "<li style='color:#ff0000;'>" + nizGreske[i] + "</li>";
		}
	}
	else
	{
		for(var i = 0; i < nizOk.length; i++)
		{
			rezultat += "<li style='color:gold;font-weight:800;'>" + nizOk[i] + "</li>";
		}
	}
	
	rezultat += "</ul>";
	
	document.getElementById("ispisGreske").style.display = "block";
	document.getElementById("ispisGreske").innerHTML = rezultat;
	
}