//json
var white = [
{
	eco: "C01",
	name: "French Opening",
	moves: "1.e4 e6 2.Sf3 d5 3.exd5 exd5 4.d4"
		
},
{
	eco: "C41",
	name: "Philidor defence",
	moves: "1.e4 e5 2.Sf3 d6 3.d4 exd4 4.Sxd4"
},
{
	eco: "C60",
	name: "Ruy Lopez",
	moves: "1.e4 e5 2.Nf 3.Nc6 3.Bb5"
		
},
{
	eco: "C62",
	name: "Ruy Lopez, old Steinz defence",
	moves: "1.e4 e6 2.Sf3 d5 3.exd5 exd5 4.d4"
		
},
{
	eco: "C40",
	name: "McConnell defence",
	moves: " 1.e4 e5 2.Sf6 Df6"
		
},
{
	eco: "D06",
	name: "Queen Gambit",
	moves: "1. d4 d5 2. c4"
		
},
{
	eco: "C30",
	name: "King Gambit",
	moves: "1. e4 e5 2. f4"
		
},
{
	eco: "B20",
	name: "Sicilian defence",
	moves: "1. e4 c5"
		
},
{
	eco: "C21",
	name: "Center Game",
	moves: "1. e4 e5 2. d4 exd4 3. Sc3"
		
}
];

//prikaz json white
var tekst = "";
tekst += "<table class='table'>";
tekst += "<tr><th>ECO code</th><th>Opening Name</th><th>Main Line</th></tr>";
for(var i = 0; i<white.length; i++){
	tekst+="<tr>"+"<td>"+white[i].eco+"</td>"+"<td>"+white[i].name +"</td>"+"<td>"+white[i].moves+"</td>";
	tekst+="</td></tr>";
}
tekst+="</table>";
document.querySelector('#white').innerHTML = tekst;

//pretraga json white 
window.onload = function(){
	document.querySelector("#btnSearch").addEventListener("click",pretraziJson);
};
function pretraziJson() {
	var unos = document.querySelector("#search").value;
	unos = unos.toUpperCase();
	console.log(unos);
	var ispis = "<ul>"; var brojac=0;
for(var i=0;i<white.length; i++){
	if(white[i].eco == unos){ brojac++;
	ispis += "<li>" + white[i].eco + " " + white[i].name + " " + white[i].moves  + "</li>";
}}
ispis +="</ul>";
if(brojac==0)
	ispis += "Not found";
console.log(brojac);
document.querySelector('.show').innerHTML = ispis;

}