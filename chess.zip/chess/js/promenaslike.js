$(document).ready(function(){
	//sakrivanje igre
	$(".cbreplay").hide();
	
	//promena slike na klik
	$("#c58v2").click(function(){
       $('#slikapozicije').attr('src','images/c58v2.png');
	});
	
	$("#b45v1").click(function(){
       $('#slikapozicije').attr('src','images/b45v1.jpg');
	});
	
	$("#b47v1").click(function(){
       $('#slikapozicije').attr('src','images/b47v1.jpg');
	});
	$("#b56").click(function(){
       $('#slikapozicije').attr('src','images/b56.png');
	});
	
	$("#b56v2").click(function(){
       $('#slikapozicije').attr('src','images/b56v2.png');
	});
	
	$("#b40").click(function(){
       $('#slikapozicije').attr('src','images/b40.jpg');
	});
	$("#b83").click(function(){
       $('#slikapozicije').attr('src','images/b83.jpg');
	});
	$("#c40vc6").click(function(){
      $(".cbreplay").show();
	});
});