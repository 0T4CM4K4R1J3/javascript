$(document).ready(function(){
	
	//dohvatanje putem ajaxa
	$.ajax({
		type: 'GET',
		url: 'js/white.json',
		success: function(podaci){
			
			//prikaz dobijenog json fajla
			var tekst = "";
			tekst += "<table class='table'>";
			tekst += "<tr><th>ECO code</th><th>Opening Name</th><th>Main Line</th></tr>";
				for(var i = 0; i<podaci.length; i++){
					tekst+="<tr>"+"<td>"+podaci[i].eco+"</td>"+"<td>"+podaci[i].name +"</td>"+"<td>"+podaci[i].moves+"</td>";
					tekst+="</td></tr>";
				}
			tekst+="</table>";
			$("#white").append(tekst);
			

			
			//pretraga jsona unosom u textualno polje
			$('#search').on("keyup", pretraziJson);
			
			function pretraziJson(){
					var unos = document.querySelector("#search").value;
					unos = unos.toUpperCase();
					console.log(unos);
					var ispis = "<ul>"; var brojac=0;
						for(var i=0;i<podaci.length; i++){
							if(podaci[i].eco == unos){ brojac++;
							ispis += "<li><h3>" + podaci[i].eco + " " + podaci[i].name + ":</br> " + podaci[i].moves  + "</h3></li>";
							}
						}
					ispis +="</ul>";
					if(brojac==0)
					ispis += "Not found any";
					console.log(brojac);
					document.querySelector('.show').innerHTML = ispis;
			}
		} 

	}); //kraj ajaxa

});