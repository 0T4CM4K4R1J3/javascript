<?php
$vote = $_REQUEST['vote'];

//preuzima stanje glasova
$filename = "poll.txt";
$content = file($filename);

//dodavanje glasa
$array = explode("||", $content[0]);
$ruylopez = $array[0];
$queen = $array[1];
$king = $array[2];
$sicilian = $array[3];

if ($vote == 0) {
  $ruylopez = $ruylopez + 1;
}
if ($vote == 1) {
  $queen = $queen + 1;
}
if ($vote == 2) {
  $king = $king + 1;
}
if ($vote == 3) {
  $sicilian = $sicilian + 1;
}

//upis glasova
$insertvote = $ruylopez."||".$queen."||".$king."||".$sicilian;
$fp = fopen($filename,"w");
fputs($fp,$insertvote);
fclose($fp);
?>